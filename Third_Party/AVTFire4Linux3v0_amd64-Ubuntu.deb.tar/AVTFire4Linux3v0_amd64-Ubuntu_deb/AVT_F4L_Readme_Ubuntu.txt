===========================================================================
AVT Fire4Linux - Ubuntu-Deb-Package related Information

Version: 3.0.0
Date:    May 26, 2010
===========================================================================

---------------
Package Content
---------------
The Ubuntu Fire4Linux Deb package consists of the following deb files:

* libdc1394-avt-22: 
  The essential library package containing the library itself and basic
  documentation. This package is required by any other Fire4Linux package 
  and must be installed first.

* libdc1394-avt-22-dbg
  Variants of all library and executable files with debug symbols. 

* libdc1394-avt-22-dev:
  Files required for development.

* libdc1394-avt-22-doc:
  Documentation and sample source code for developers.

* libdc1394-avt-utils:
  Additional tools and compiled samples.

* cc1394:
  Comprehensive and easily operated viewer application to test AVT cameras
  and to experiment with their special features without any programming.
  
For further information please refer to the corresponding release notes 
file.


-----------------------------
Supported Linux Distributions
-----------------------------
The enclosed deb files are expected to work on Ubuntu 10.4 systems.


------------
Installation
------------
Each deb can be installed 
- either by right-clicking and choosing "Open with GDebi Package Installer" 
- or by executing "sudo dpkg -i <packagename>".




  
  
